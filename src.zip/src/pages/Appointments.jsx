import React from "react";

const Appointments = () => {
  return (
    <div className="container mt-4">
      <h3>مدیریت نوبت‌ها</h3>
      {/* فرم ثبت نوبت جدید */}
      {/* جدول نوبت‌های ثبت‌شده */}
    </div>
  );
};

export default Appointments;